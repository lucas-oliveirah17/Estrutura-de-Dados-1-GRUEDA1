void calcVantagens(int numeroHoras, float salarioHora, int numeroFilhos, float valorPorFilho, float *salarioBruto, float*salarioFamilia, float *vantagens);
void calcDeducoes(float salarioBruto, float taxaIR, float *INSS, float *IPRF, float *deducoes);
